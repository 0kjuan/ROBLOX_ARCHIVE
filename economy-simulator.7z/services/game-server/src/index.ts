import server from './server';
server();
