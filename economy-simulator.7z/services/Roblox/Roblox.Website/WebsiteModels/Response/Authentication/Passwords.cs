namespace Roblox.Website.WebsiteModels.Authentication;

public class ChangePasswordRequest
{
    public string currentPassword { get; set; }
    public string newPassword { get; set; }
}

