namespace Roblox.Website.WebsiteModels;

public class UpdateDescriptionRequest
{
    public string description { get; set; }
}