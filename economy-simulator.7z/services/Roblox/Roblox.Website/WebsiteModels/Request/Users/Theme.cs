using Roblox.Models.Users;

namespace Roblox.Website.WebsiteModels;

public class SetThemeRequest
{
    public ThemeTypes themeType { get; set; }
}

