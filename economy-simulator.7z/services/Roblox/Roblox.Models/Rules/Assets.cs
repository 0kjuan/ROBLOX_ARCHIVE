namespace Roblox.Models.Assets;

public static class Rules
{
    public const int NameMaxLength = 100;
    public const int DescriptionMaxLength = 1000;
}

