namespace Roblox.Exceptions.Services.Assets;

public class AssetNameTooShortException : Exception { }
public class AssetNameTooLongException : Exception { }
public class AssetDescriptionTooLongException : Exception { }