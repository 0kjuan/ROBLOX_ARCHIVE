<script lang="ts">
	const year = new Date().getFullYear();
</script>

<footer class="footer mt-auto py-3 bg-light">
	<div class="container">
		<p class="text-muted mb-0">
			<span class="fw-bold">CONFIDENTIAL</span>. All content within this webpage is confidential. Images, recordings, video recordings, photographs, screenshots, or any other forms of copying and/or storing this web page, website, and/or content (physically and/or digitally) are not permitted unless required by law.
		</p>
		<p class="text-muted mb-0 mt-2">
			&copy;{new Date().getFullYear()}
			{window.location.hostname}
		</p>
	</div>
</footer>
